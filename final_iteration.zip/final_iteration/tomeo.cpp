//
//    ______
//   /_  __/___  ____ ___  ___  ____
//    / / / __ \/ __ `__ \/ _ \/ __ \
//   / / / /_/ / / / / / /  __/ /_/ /
//  /_/  \____/_/ /_/ /_/\___/\____/
//              video for sports enthusiasts...
//
//

#include <iostream>
#include <QApplication>
#include <QtMultimediaWidgets/QVideoWidget>
#include <QMediaPlaylist>
#include <string>
#include <vector>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QHBoxLayout>
#include <QtCore/QFileInfo>
#include <QtWidgets/QFileIconProvider>
#include <QDesktopServices>
#include <QImageReader>
#include <QMessageBox>
#include <QtCore/QDir>
#include <QtCore/QDirIterator>
#include <QPushButton>
#include <QIcon>
#include <QScrollArea>
#include <QStyle>
#include <QSlider>
#include <QComboBox>
#include <QDialog>
#include <QTableWidget>
#include <QTableWidgetItem>
#include <QMessageBox>
#include <QMenu>
#include <QMenuBar>
#include <QScrollArea>
#include <QFileDialog>
#include <QEvent>
#include "the_player.h"
#include "the_button.h"
#include "loginwindow.h"
#include "customvideowidget.h"
#include "commentwidget.h"

// read in videos and thumbnails to this directory
std::vector<TheButtonInfo> getInfoIn (std::string loc) {

    std::vector<TheButtonInfo> out =  std::vector<TheButtonInfo>();
    QDir dir(QString::fromStdString(loc) );
    QDirIterator it(dir);

    while (it.hasNext()) { // for all files

        QString f = it.next();

            if (f.contains("."))

#if defined(_WIN32)
            if (f.contains(".wmv"))  { // windows
#else
            if (f.contains(".mp4") || f.contains("MOV"))  { // mac/linux
#endif

            QString thumb = f.left( f .length() - 4) +".png";
            if (QFile(thumb).exists()) { // if a png thumbnail exists
                QImageReader *imageReader = new QImageReader(thumb);
                    QImage sprite = imageReader->read(); // read the thumbnail
                    if (!sprite.isNull()) {
                        QIcon* ico = new QIcon(QPixmap::fromImage(sprite)); // voodoo to create an icon for the button
                        QUrl* url = new QUrl(QUrl::fromLocalFile( f )); // convert the file location to a generic url
                        out . push_back(TheButtonInfo( url , ico  ) ); // add to the output list
                    }
                    else
                        qDebug() << "warning: skipping video because I couldn't process thumbnail " << thumb << endl;
            }
            else
                qDebug() << "warning: skipping video because I couldn't find thumbnail " << thumb << endl;
        }
    }

    return out;
}

QWidget * init_threeWidget(QPushButton* commentButton){
    // 创建评论、点赞、分享按钮
    QPushButton* favoriteButton = new QPushButton();
    QPushButton* shareButton = new QPushButton();

    // 设置图标和尺寸
    commentButton->setIcon(QIcon(":/img/comment.png"));
    favoriteButton->setIcon(QIcon(":/img/favorite.png"));
    shareButton->setIcon(QIcon(":/img/share.png"));

    commentButton->setIconSize(QSize(30, 40));
    favoriteButton->setIconSize(QSize(30, 40));
    shareButton->setIconSize(QSize(30, 40));

    // 创建垂直布局
    QWidget *tripletWidget = new QWidget();
    QVBoxLayout* tripletLayout = new QVBoxLayout();
    tripletWidget->setLayout(tripletLayout);

    // 应用按钮样式
    auto applyButtonStyle = [](QPushButton *button, QSize size) {
        button->setFixedSize(size);
        button->setStyleSheet("QPushButton {"
                              "background-color: transparent;"
                              "border: none;"
                              "}"
                              "QPushButton:hover {"
                              "background-color: rgba(255, 255, 255, 0.1);"
                              "}");
    };

    applyButtonStyle(commentButton, QSize(40, 50));
    applyButtonStyle(favoriteButton, QSize(40, 50));
    applyButtonStyle(shareButton, QSize(40, 50));

    // 将按钮添加到垂直布局
    tripletLayout->addWidget(commentButton);
    tripletLayout->addWidget(favoriteButton);
    tripletLayout->addWidget(shareButton);

    // 控制按钮交互
    favoriteButton->connect(favoriteButton, &QPushButton::clicked, [favoriteButton]() {
        if (favoriteButton->icon().name() == QIcon(":/img/favorite.png").name()) {
            favoriteButton->setIcon(QIcon(":/img/favorite2.png"));
        } else {
            favoriteButton->setIcon(QIcon(":/img/favorite.png"));
        }
    });

    shareButton->connect(shareButton, &QPushButton::clicked, [shareButton]() {
        QDialog *dialog = new QDialog();
        dialog->setWindowTitle("分享");
        dialog->setMinimumSize(400, 300);  // 设置最小大小

        QVBoxLayout *layout = new QVBoxLayout(dialog);

        QLabel *label = new QLabel("尊敬的用户:\n感谢你的分享", dialog);
        label->setAlignment(Qt::AlignCenter);  // 中心对齐
        label->setStyleSheet("font-size:18px;"
                             "font-weight:400;");
        layout->addWidget(label);

        // 创建社交媒体图标并添加到布局
        QHBoxLayout *iconLayout = new QHBoxLayout();

        // 假设有社交媒体图标文件
        QStringList iconPaths = {":/img/Facebook.png", ":/img/wechat.png", ":/img/github.png"};
        for (const QString &path : iconPaths) {
            QLabel *iconLabel = new QLabel(dialog);
            QPixmap pixmap(path);
            iconLabel->setPixmap(pixmap.scaled(50, 50, Qt::KeepAspectRatio));  // 调整图标大小
            iconLabel->setAlignment(Qt::AlignCenter);
            iconLayout->addWidget(iconLabel);
        }
        layout->addLayout(iconLayout);

        // 添加一个OK按钮
        QPushButton *okButton = new QPushButton("确认", dialog);
        okButton->setStyleSheet("background-color: #4CAF50;"
                                "color: white; "
                                "font-size: 16px;"
                                "width；80px;"
                                "margin:0 auto;"
                                "height:30px"); // 设置按钮样式
        layout->addWidget(okButton);

        okButton->connect(okButton, &QPushButton::clicked, dialog, &QDialog::accept);

        dialog->setLayout(layout); // 设置布局
        dialog->exec();  // 显示模态对话框
    });

    return tripletWidget;
}



QWidget * init_controllWidget(ThePlayer * player, QPushButton* playPauseButton){
    //控制容器
    QWidget *controllWidget = new QWidget();
    QHBoxLayout* controll_layout = new QHBoxLayout();
    controllWidget->setLayout(controll_layout);

    // 创建控制按钮
    QPushButton* previousSeekButton = new QPushButton();
    QPushButton* nextSeekButton = new QPushButton();
    QPushButton* previousButton = new QPushButton();
    QPushButton* nextButton = new QPushButton();
    QPushButton* muteButton = new QPushButton();
    muteButton->setFixedSize(100, 50); // 静音按钮设置固定大小为 100x50 像素
    //样式
    previousSeekButton->setStyleSheet("border: none; background: transparent");
    nextSeekButton->setStyleSheet("border: none; background: transparent");
    previousButton->setStyleSheet("border: none; background: transparent");
    nextButton->setStyleSheet("border: none; background: transparent");
    muteButton->setStyleSheet("border: none; background: transparent");
    playPauseButton->setStyleSheet("border: none; background: transparent");
    // 创建音量滑块
    QSlider *volumeSlider = new QSlider(Qt::Horizontal);
    volumeSlider->setRange(0, 100); // 范围从 0 到 100
    volumeSlider->setValue(0); // 默认音量 0%
    volumeSlider->setMaximumWidth(100);
    volumeSlider->setStyleSheet(
        "QSlider::groove:horizontal {"
        "    border: 1px solid #999999;"
        "    height: 4px;"
        "    background: #e1e1e1;"
        "    border-radius: 2px;"
        "}"
        "QSlider::handle:horizontal {"
        "    background: #2196F3;" // 设置滑块的颜色为蓝色
        "    border: 2px solid #2196F3;" // 设置边框颜色为蓝色
        "    width: 10px;" // 设置圆点的直径
        "    height: 10px;" // 设置圆点的高度
        "    border-radius: 5px;" // 使其成为圆形
        "    margin-top: -3px;" // 调整圆点垂直位置
        "    margin-bottom: -3px;"
        "}"
        "QSlider::sub-page:horizontal {"
        "    background: #2196F3;" // 设置已选择部分的背景为蓝色
        "    border-radius: 2px;"
        "}"
        "QSlider::add-page:horizontal {"
        "    background: #e1e1e1;" // 设置未选择部分的背景颜色
        "    border-radius: 2px;"
        "}"
        );
    //设置控制按钮样式
    playPauseButton ->setIcon(playPauseButton ->style()->standardIcon(QStyle::SP_MediaPause));
    playPauseButton ->setIconSize(QSize(40, 40));
    previousButton->setIcon(previousButton->style()->standardIcon(QStyle::SP_MediaSkipBackward));
    previousButton->setIconSize(QSize(40, 40));
    nextButton ->setIcon(nextButton->style()->standardIcon(QStyle::SP_MediaSkipForward));
    nextButton ->setIconSize(QSize(40, 40));
    muteButton ->setIcon(muteButton->style()->standardIcon(QStyle::SP_MediaVolumeMuted));
    muteButton ->setIconSize(QSize(40, 40));
    previousSeekButton->setIcon(previousSeekButton->style()->standardIcon(QStyle::SP_MediaSeekBackward));
    previousSeekButton->setIconSize(QSize(40, 40));
    nextSeekButton->setIcon(nextSeekButton->style()->standardIcon(QStyle::SP_MediaSeekForward));
    nextSeekButton->setIconSize(QSize(40, 40));

    // // 将按钮添加到布局中
    controll_layout->addWidget(previousButton);
    controll_layout->addWidget(previousSeekButton);
    controll_layout->addWidget(playPauseButton);
    controll_layout->addWidget(nextSeekButton);
    controll_layout->addWidget(nextButton);
    controll_layout->addWidget(muteButton);
    controll_layout->addWidget(volumeSlider);

    // 设置布局对齐方式为右对齐
    controll_layout->setAlignment(Qt::AlignRight);  // 这行是关键
    // 添加一个空的占位符，确保按钮从右开始排列
    QSpacerItem* spacer = new QSpacerItem(70, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);
    controll_layout->insertItem(0, spacer);  // 将空的占位符添加到布局的最前面


    // 连接按钮的信号和槽
    playPauseButton->connect(playPauseButton, &QPushButton::clicked, [=]() {player->playPause(playPauseButton);});
    // 这里连接了两个槽函数，一个是跳转到下一个视频，另一个是更新按钮状态
    nextButton->connect(nextButton, &QPushButton::clicked, player, [=]() {
        player->nextVideo(); // 跳转到下一个视频
        player->updatePlayPauseButtonState(playPauseButton); // 更新播放/暂停按钮的状态
    });
    previousButton->connect(previousButton, &QPushButton::clicked, player, [=]() {
        player->previousVideo(); // 跳转到下一个视频
        player->updatePlayPauseButtonState(playPauseButton); // 更新播放/暂停按钮的状态
    });

    // 连接快退快进按钮的信号和槽
    previousSeekButton->connect(previousSeekButton, &QPushButton::clicked, player, [=]() {
        player->previousSeek(player); // 快退 5 秒（5000 毫秒）
    });
    nextSeekButton->connect(nextSeekButton, &QPushButton::clicked, player, [=]() {
        player->nextSeek(player); // 快退 5 秒（5000 毫秒）
    });

    // 连接静音按钮的信号和槽
    muteButton->connect(muteButton, &QPushButton::clicked, player, [=]() {
        player->muteAudio(volumeSlider); // 跳转到下一个视频
    });

    volumeSlider->connect(volumeSlider, SIGNAL(valueChanged(int)), player, SLOT(setVolume(int)));
    return controllWidget;
}

QWidget * init_progressWidget(ThePlayer * player){
    //进度条容器
    QSlider* progressbar = new QSlider(Qt::Horizontal);//Video progress bar
    QComboBox * speed = new QComboBox;
    QWidget *progressWidget = new QWidget();
    QHBoxLayout* progress_layout = new QHBoxLayout();

    // 创建时钟显示用的 QLabel
    QLabel *timeLabel = new QLabel("00:00", progressWidget);
    timeLabel->setAlignment(Qt::AlignCenter);

    progress_layout->addWidget(timeLabel);  // 将时钟添加到布局左侧
    progressWidget->setLayout(progress_layout);
    progress_layout -> addWidget(progressbar);
    progress_layout -> addWidget(speed);

    //绑定进度条动作
    player->connect(player, &QMediaPlayer::durationChanged, progressbar, &QSlider::setMaximum);
    player->connect(player, &QMediaPlayer::positionChanged, progressbar, &QSlider::setValue);
    progressbar->connect(progressbar, &QSlider::sliderMoved, player, &QMediaPlayer::setPosition);

    //时速
    speed->addItem("0.5x", QVariant(0.5));
    speed->addItem("1x", QVariant(1));
    speed->addItem("1.5x", QVariant(1.5));
    speed->addItem("2x", QVariant(2));
    speed->addItem("2.5x", QVariant(2.5));
    speed->addItem("3x", QVariant(3));
    speed->setCurrentIndex(1);
    speed->setMaximumWidth(80);

    // 连接信号与槽，直接设置播放速度
    speed->connect(speed, QOverload<int>::of(&QComboBox::currentIndexChanged), player,
                   [player, speed] {
                       double videospeed = speed->currentData().toDouble(); // 获取当前选中项的播放速度
                       player->setPlaybackRate(videospeed); // 设置播放速度
                   });

    // 使用定时器来定期更新时钟显示
    QTimer *timer = new QTimer(progressWidget);
    QObject::connect(timer, &QTimer::timeout, [=]() {
        int currentPos = player->position();  // 获取当前播放时间
        int minutes = (currentPos / 1000) / 60;
        int seconds = (currentPos / 1000) % 60;
        QString timeString = QString("%1:%2")
                                 .arg(minutes, 2, 10, QChar('0'))
                                 .arg(seconds, 2, 10, QChar('0'));
        timeLabel->setText(timeString);  // 更新 QLabel 显示的时间
    });
    timer->start(900);  // 每秒更新一次

    //设置样式
    timeLabel->setStyleSheet("color: white;"); // 设置时钟文字为白色
    progressbar->setStyleSheet("QSlider::groove:horizontal { background: #333; height: 5px; }"
                               "QSlider::handle:horizontal { background: white; width: 10px; border-radius: 5px; }"
                               "QSlider { height: 8px; background: #444; }");

    progressbar->setStyleSheet(
        "QSlider::groove:horizontal {"
        "    border: 1px solid #bbb;"       // 外边框
        "    background: #333;"             // 未划过部分背景色
        "    height: 6px;"                  // 进度条高度
        "    border-radius: 3px;"           // 圆角设计
        "}"
        "QSlider::handle:horizontal {"
        "    background: white;"            // 滑块颜色
        "    border: 1px solid #777;"       // 滑块边框
        "    width: 12px;"                  // 滑块宽度
        "    height: 12px;"                 // 滑块高度
        "    border-radius: 6px;"           // 滑块圆角
        "    margin: -3px 0;"               // 滑块位置调整
        "}"
        "QSlider::sub-page:horizontal {"
        "    background: #3399FF;"          // 已划过部分为粉红色
        "    border-radius: 3px;"           // 圆角设计
        "}"
        "QSlider::add-page:horizontal {"
        "    background: #444;"             // 未划过部分为深灰色
        "    border-radius: 3px;"           // 圆角设计
        "}"
        );
    // 设置时速框样式并去掉下拉箭头
    speed->setStyleSheet(
        "QComboBox {"
        "   background-color: white;"
        "   color: black;"
        "   border: 1px solid #888;"
        "   border-radius: 5px;"
        "   padding: 2px;"
        "   padding-right: 0px;"  // 去掉右侧的空间
        "   min-width: 40px;"  // 最小宽度
        "}"
        "QComboBox::drop-down {"
        "   width: 0px;"         // 隐藏下拉箭头
        "   border: none;"
        "}"
        "QComboBox QAbstractItemView {"
        "   background-color: white;"
        "   selection-background-color: #3399FF;"
        "   selection-color: black;"
        "}"
        );

    return progressWidget;
}


QWidget * init_totalWidget(QVideoWidget *videoWidget,
                          CommentWidget *commentWidget,
                          QWidget *progressWidget,
                          QScrollArea *scrollArea,
                          QWidget *controllWidget,
                          QWidget * tripleWidget,
                          QPushButton* commentButton,
                          QWidget * phoneWidget){
    //加入进度条 垂直容器
    QWidget *videoAndprogressWidget = new QWidget;
    QVBoxLayout *videoAndprogresslayout = new QVBoxLayout();
    videoAndprogressWidget->setLayout(videoAndprogresslayout);
    videoAndprogresslayout -> addWidget(videoWidget);
    videoAndprogresslayout -> addWidget(progressWidget);
    // 设置视频和进度条容器背景为黑色
    videoAndprogressWidget->setStyleSheet("background-color: black;");

    QWidget *controlllAndphonelayoutWidget = new QWidget;
    QHBoxLayout *controlllAndphonelayout = new QHBoxLayout();
    controlllAndphonelayoutWidget->setLayout(controlllAndphonelayout);
    controlllAndphonelayout -> addWidget(phoneWidget);
    controlllAndphonelayout -> addWidget(controllWidget);

    QWidget *videoAndcontrollWidget = new QWidget;
    QVBoxLayout *videoAndcontrolllayout = new QVBoxLayout();

    videoAndcontrollWidget->setLayout(videoAndcontrolllayout);
    videoAndcontrolllayout -> addWidget(videoAndprogressWidget);
    videoAndcontrolllayout -> addWidget(controlllAndphonelayoutWidget);

    // 设置 descriptionWidget 初始为隐藏状态
    commentWidget->setVisible(false);

    // 连接 commentButton 的点击信号到切换函数
    QObject::connect(commentButton, &QPushButton::clicked, [=]() {
        // 切换 descriptionWidget 的可见性
        bool isVisible = commentWidget->isVisible();
        commentWidget->setVisible(!isVisible); // 如果可见则隐藏，如果隐藏则显示

        // 根据状态输出调试信息
        qDebug() << "Description widget is now" << (isVisible ? "hidden" : "visible");
    });

    //加入选项 水平容器
    QWidget *videoAndbuttonWidget = new QWidget;
    QHBoxLayout *videoAndbuttonlayout = new QHBoxLayout();
    videoAndbuttonWidget->setLayout(videoAndbuttonlayout);
    videoAndbuttonlayout -> addWidget(videoAndcontrollWidget);
    videoAndbuttonlayout -> addWidget(commentWidget);
    videoAndbuttonlayout -> addWidget(tripleWidget);
    videoAndbuttonlayout -> addWidget(scrollArea);


    //加入控制 垂直容器
    QWidget *totalWidget = new QWidget();
    QVBoxLayout *totallayout = new QVBoxLayout();
    totalWidget->setLayout(totallayout);
    totallayout -> addWidget(videoAndbuttonWidget);

    // //修改样式
    // videoAndprogressWidget->setStyleSheet("background-color: black;");
    return totalWidget;
}


CommentWidget *init_commentWidget(){
    CommentWidget *commentWidget = new CommentWidget();
    commentWidget->setMinimumWidth(240); // 设置最小宽度为 200
    // 添加一些测试评论
    QPixmap avatar1(":/img/user.png");
    QPixmap avatar2(":/img/user.png");

    commentWidget->addComment("Alice", "This is a great video!", avatar1);
    commentWidget->addComment("Bob", " I really enjoyed it.", avatar2);
    commentWidget->addComment("Charlie", "Amazing work! Keep it up!", avatar1);
    return commentWidget;
}






void init_menuWidget(QMenuBar *menuBar, QWidget *window){
    // 设置菜单栏样式
    menuBar->setStyleSheet("QMenuBar { background-color: #F4F4F4; }");

    QMenu *fileMenu = menuBar->addMenu("File");
    QMenu *toolMenu = menuBar->addMenu("Tool");
    QMenu *helpMenu = menuBar->addMenu("Help");
    QMenu *languageMenu = menuBar->addMenu("Language");

    QAction *importAction1 = new QAction(QIcon(":/img/file1.png"), "Import local video", fileMenu);
    QAction *importAction2 = new QAction(QIcon(":/img/file2.png"), "Import external video", fileMenu);
    QAction *lightAction = new QAction(QIcon(":/img/video.png"), "Change video image", toolMenu);
    QAction *noteAction = new QAction(QIcon(":/img/note.png"), "note", toolMenu);
    QAction *muluAction = new QAction(QIcon(":/img/mulu.png"), "menu", helpMenu);
    QAction *chajianAction = new QAction(QIcon(":/img/chajian.png"), "Plugin", helpMenu);
    QAction *englishAction = new QAction(QIcon(":/img/english.png"), "English", languageMenu);
    QAction *chineseAction = new QAction(QIcon(":/img/chinese.png"), "chinese", languageMenu);

    importAction1->connect(importAction1, &QAction::triggered, [&]() {
        // 打开文件对话框选择文件
        QString fileName = QFileDialog::getOpenFileName(window, QObject::tr("Open Video"), "", QObject::tr("Video Files (*.mp4 *.avi *.mov)"));

        if (!fileName.isEmpty()) {
            // 如果选择了文件，显示文件路径
            QMessageBox::information(window, QObject::tr("File Selected"), QObject::tr("You selected: ") + fileName);
        } else {
            // 如果没有选择文件，提示用户
            QMessageBox::warning(window, QObject::tr("No File Selected"), QObject::tr("No file was selected"));
        }
    });

    lightAction->connect(lightAction, &QAction::triggered, [&]() {
        // 创建调整窗口
        QWidget *adjustWindow = new QWidget();
        adjustWindow->setWindowTitle("Adjust Brightness and Contrast");
        adjustWindow->setFixedSize(300, 150);

        QVBoxLayout *adjustLayout = new QVBoxLayout(adjustWindow);

        // 创建亮度滑块和标签
        QLabel *brightnessLabel = new QLabel("Brightness:", adjustWindow);
        QSlider *brightnessSlider = new QSlider(Qt::Horizontal, adjustWindow);
        brightnessSlider->setRange(0, 100); // 假设亮度范围是 0-100
        brightnessSlider->setValue(50);     // 默认值 50

        // 创建对比度滑块和标签
        QLabel *contrastLabel = new QLabel("Contrast:", adjustWindow);
        QSlider *contrastSlider = new QSlider(Qt::Horizontal, adjustWindow);
        contrastSlider->setRange(0, 100); // 假设对比度范围是 0-100
        contrastSlider->setValue(50);     // 默认值 50

        // 将控件添加到布局
        adjustLayout->addWidget(brightnessLabel);
        adjustLayout->addWidget(brightnessSlider);
        adjustLayout->addWidget(contrastLabel);
        adjustLayout->addWidget(contrastSlider);

        // 显示调整窗口
        adjustWindow->show();

        // 响应滑块变化（示例，打印亮度和对比度值）
        QObject::connect(brightnessSlider, &QSlider::valueChanged, [=](int value) {
            qDebug() << "Brightness:" << value;
        });
        QObject::connect(contrastSlider, &QSlider::valueChanged, [=](int value) {
            qDebug() << "Contrast:" << value;
        });
    });

    // 更新菜单项文本的槽函数
    auto updateMenuText = [&](QString language) {
        if (language == "en") {
            // fileMenu->setTitle("File");
            // toolMenu->setTitle("Tool");
            // helpMenu->setTitle("Help");
            // languageMenu->setTitle("Language");

            // importAction1->setText("Import local video");
            // importAction2->setText("Import external video");
            // lightAction->setText("Change video image");
            // noteAction->setText("Note");
            // muluAction->setText("Menu");
            // chajianAction->setText("Plugin");

            // englishAction->setText("English");
            // chineseAction->setText("Chinese");
        } else if (language == "zh") {
            // fileMenu->setTitle("文件");
            // toolMenu->setTitle("工具");
            // helpMenu->setTitle("帮助");
            // languageMenu->setTitle("语言");

            // importAction1->setText("导入本地视频");
            // importAction2->setText("导入外部视频");
            // lightAction->setText("更改视频图像");
            // noteAction->setText("笔记");
            // muluAction->setText("菜单");
            // chajianAction->setText("插件");

            // englishAction->setText("英文");
            // chineseAction->setText("中文");
        }
    };

    // 点击按钮时切换语言
    QObject::connect(englishAction, &QAction::triggered, [&]() {
        updateMenuText("en");  // 设置为英文
    });

    QObject::connect(chineseAction, &QAction::triggered, [&]() {
        updateMenuText("zh");  // 设置为中文
    });




    fileMenu->addAction(importAction1);
    fileMenu->addAction(importAction2);
    toolMenu->addAction(lightAction);
    toolMenu->addAction(noteAction);
    helpMenu->addAction(muluAction);
    helpMenu->addAction(chajianAction);
    languageMenu->addAction(englishAction);
    languageMenu->addAction(chineseAction);
}


int main(int argc, char *argv[]) {

    // let's just check that Qt is operational first
    qDebug() << "Qt version: " << QT_VERSION_STR << endl;
    qDebug() << "Current working directory: " << QDir::currentPath();
    // create the Qt Application
    QApplication app(argc, argv);

    // 创建并显示登录窗口
    loginWindow loginwindow;

    if (loginwindow.exec() == QDialog::Accepted) {

        // 登录成功，进入视频播放器界面
        qDebug() << "Login successful. Proceeding to video player.";

        // 之后初始化视频播放器界面
        std::vector<TheButtonInfo> videos;
        if (argc == 2) {
            videos = getInfoIn(std::string(argv[1]));
        }

        if (videos.size() == 0) {
            const int result = QMessageBox::information(
                NULL,
                QString("Tomeo"),
                QString("no videos found! Add command line argument to \"quoted\" file location."));
            exit(-1);
        }

        //初始化视频容器
        CustomVideoWidget *videoWidget = new CustomVideoWidget;
        ThePlayer *player = new ThePlayer;
        player->setVideoOutput(videoWidget);

        //初始化控制容器
        QPushButton* playPauseButton = new QPushButton();
        QWidget *controllWidget = init_controllWidget(player, playPauseButton);



        //初始化进度条容器
        QWidget *progressWidget = init_progressWidget(player);

        //初始化文本框容器
        // QWidget *descriptionWidget = init_descriptionWidget();

        //初始化评论容器
        CommentWidget *commentWidget = init_commentWidget();

        //初始化点赞容器
        QPushButton* commentButton = new QPushButton();
        QWidget *threeWidget = init_threeWidget(commentButton);

        //初始化按钮容器
        QWidget *buttonWidget = new QWidget();
        std::vector<TheButton*> buttons;
        QVBoxLayout *layout = new QVBoxLayout();
        buttonWidget->setLayout(layout);
        for (int i = 0; i < 3; i++) {
            TheButton *button = new TheButton(buttonWidget);
            button->connect(button, SIGNAL(jumpTo(TheButtonInfo*)), player, SLOT(jumpTo(TheButtonInfo*)));
            buttons.push_back(button);
            layout->addWidget(button);
            button->init(&videos.at(i));
        }
        player->setContent(&buttons, &videos);
        // 使用QScrollArea 包装按钮组件
        QScrollArea *scrollArea = new QScrollArea;
        scrollArea->setWidgetResizable(true); // 自动调整内容大小
        scrollArea->setWidget(buttonWidget); // 设置其为滚动区域的中心控件
        scrollArea->setMinimumWidth(160); // 将滚动区域的最小宽度设置更窄
        scrollArea->setMaximumWidth(200); // 设置最大宽度，使得按钮区域较窄

        // 初始时隐藏进度条
        progressWidget->setVisible(false);
        // 连接 CustomVideoWidget 信号与槽
        QObject::connect(videoWidget, &CustomVideoWidget::showProgressWidget, [progressWidget]() {
            progressWidget->setVisible(true);  // 显示进度条
        });

        QObject::connect(videoWidget, &CustomVideoWidget::hideProgressWidget, [progressWidget]() {
            progressWidget->setVisible(false);  // 隐藏进度条
        });

        QPushButton* phoneButton = new QPushButton();
        QPushButton* tabletButton = new QPushButton();
        QPushButton* desktopButton = new QPushButton();
        QWidget *phoneWidget = new QWidget();
        QHBoxLayout* phone_layout = new QHBoxLayout();
        phoneWidget->setLayout(phone_layout);

        phoneButton->setIcon(QIcon(":/img/phone.png"));
        phoneButton->setIconSize(QSize(30, 30));
        tabletButton->setIcon(QIcon(":/img/tablet.png"));
        tabletButton->setIconSize(QSize(30, 30));
        desktopButton->setIcon(QIcon(":/img/desktop.png"));
        desktopButton->setIconSize(QSize(30, 30));
        phone_layout -> addWidget(phoneButton);
        phone_layout -> addWidget(tabletButton);
        phone_layout -> addWidget(desktopButton);
        // 去除边框样式
        QString buttonStyle = "QPushButton { border: none; }";
        phoneButton->setStyleSheet(buttonStyle);
        tabletButton->setStyleSheet(buttonStyle);
        desktopButton->setStyleSheet(buttonStyle);
        phoneWidget->setFixedWidth(120);
        // 设置固定大小，确保按钮与图标大小一致
        phoneButton->setFixedSize(40, 40);
        tabletButton->setFixedSize(40, 40);
        desktopButton->setFixedSize(40, 40);


        // create the main window and layout
        QWidget window;
        QVBoxLayout *top = new QVBoxLayout();
        // 去除布局的外边距和控件间距
        top->setContentsMargins(0, 0, 0, 0); // 设置外边距为 0
        top->setSpacing(0); // 设置控件间距为 0
        window.setLayout(top);
        window.setWindowTitle("tomeo");
        window.setMinimumSize(800, 680);
        // 创建菜单栏
        QMenuBar *menuBar = new QMenuBar(&window);
        top->setMenuBar(menuBar); // 将菜单栏添加到布局
        init_menuWidget(menuBar, &window);

        //组合视频,进度条,按钮,控制容器
        QWidget *totalWidget = init_totalWidget(videoWidget,
                                                commentWidget,
                                                progressWidget,
                                                scrollArea,
                                                controllWidget,
                                                threeWidget,
                                                commentButton,
                                                phoneWidget);

        // add the video and the buttons to the top level widget
        top->addWidget(totalWidget);


        // 连接 desktopButton 点击信号到槽函数
        QObject::connect(desktopButton, &QPushButton::clicked, [&window, scrollArea]() {
            // 调整窗口大小
            qDebug() << "Desktop button clicked! Resizing window...";
            scrollArea->show();
            window.resize(1500, 900);
        });
        QObject::connect(tabletButton, &QPushButton::clicked, [&window, scrollArea]() {
            // 调整窗口大小
            qDebug() << "Desktop button clicked! Resizing window...";
            scrollArea->show();
            window.resize(1300, 700);
        });
        // 连接 phoneButton 点击信号到槽函数
        QObject::connect(phoneButton, &QPushButton::clicked, [&window, scrollArea]() {
            // 调整窗口大小
            qDebug() << "Phone button clicked! Resizing window and hiding buttonWidget...";
            window.resize(600, 800); // 设置窗口大小为 600x400

            // 隐藏 buttonWidget
            scrollArea->hide();
        });
        // showtime!
        window.show();

        // wait for the app to terminate
        return app.exec();
    }

    // 如果登录失败，退出应用程序
    qDebug() << "Login failed.";
    return 0;
}
