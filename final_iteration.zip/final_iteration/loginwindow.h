#ifndef LOGINWINDOW_H
#define LOGINWINDOW_H

#include <QDialog>
#include <QLabel>
#include <QLineEdit>
#include <QPushButton>
#include <QVBoxLayout>
#include <QMessageBox>
#include <QPalette>

class loginWindow : public QDialog {  // 继承 QDialog
    Q_OBJECT
public:
    loginWindow(QWidget *parent = nullptr) : QDialog(parent) {  // 使用 QDialog 构造函数
        setWindowTitle("Login");
        setMinimumSize(400, 300);  // 设置最小大小

        // 设置布局
        QVBoxLayout *layout = new QVBoxLayout(this);

        // 创建用户名和密码输入框
        QLabel *usernameLabel = new QLabel("Username:");
        QLineEdit *usernameEdit = new QLineEdit();
        QLabel *passwordLabel = new QLabel("Password:");
        QLineEdit *passwordEdit = new QLineEdit();

        // 设置默认用户名和密码
        usernameEdit->setText("Tom");  // 默认用户名
        passwordEdit->setText("123");  // 默认密码, 注意: 明文显示
        passwordEdit->setEchoMode(QLineEdit::Password); // 设置密码框

        // 创建登录按钮
        QPushButton *loginButton = new QPushButton("Login");

        // 将控件添加到布局
        layout->addWidget(usernameLabel);
        layout->addWidget(usernameEdit);
        layout->addWidget(passwordLabel);
        layout->addWidget(passwordEdit);
        layout->addWidget(loginButton);

        // 设置样式表
        usernameEdit->setStyleSheet("QLineEdit {"
                                    "border: 1px solid #ccc;"
                                    "border-radius: 5px;"
                                    "padding: 10px;"
                                    "background-color: white;"
                                    "}"
                                    "QLineEdit:focus {"
                                    "border: 1px solid #4CAF50;"
                                    "}");

        passwordEdit->setStyleSheet("QLineEdit {"
                                    "border: 1px solid #ccc;"
                                    "border-radius: 5px;"
                                    "padding: 10px;"
                                    "background-color: white;"
                                    "}"
                                    "QLineEdit:focus {"
                                    "border: 1px solid #4CAF50;"
                                    "}");

        loginButton->setStyleSheet("QPushButton {"
                                   "background-color: #4CAF50;"
                                   "color: white;"
                                   "width: 50px;"
                                   "margin: 0 auto;"
                                   "margin-top: 30 auto;"
                                   "border-radius: 5px;"
                                   "padding: 10px;"
                                   "}"
                                   "QPushButton:hover {"
                                   "background-color: #45a049;"
                                   "}");



        // 连接登录按钮的点击信号到槽函数
        connect(loginButton, &QPushButton::clicked, this, [=]() {
            QString username = usernameEdit->text();
            QString password = passwordEdit->text();

            if (username == "Tom" && password == "123") {
                // 登录成功，关闭登录窗口，进入主界面
                accept(); // 允许关闭窗口
            } else {
                // 登录失败，显示错误信息
                QMessageBox::warning(this, "Login Failed", "Incorrect username or password.");
            }
        });
    }
};
#endif // LOGINWINDOW_H
