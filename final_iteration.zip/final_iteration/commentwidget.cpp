#include "commentwidget.h"

CommentWidget::CommentWidget(QWidget *parent)
    : QWidget(parent) {
    // 设置滚动区域
    QScrollArea *scrollArea = new QScrollArea(this);
    scrollArea->setWidgetResizable(true);

    // 容器小部件
    QWidget *container = new QWidget();
    commentsLayout = new QVBoxLayout(container);
    container->setLayout(commentsLayout);

    // 设置滚动区域内容
    scrollArea->setWidget(container);

    // 主布局
    QVBoxLayout *mainLayout = new QVBoxLayout(this);
    mainLayout->addWidget(scrollArea);
    setLayout(mainLayout);
}

void CommentWidget::addComment(const QString &username, const QString &comment, const QPixmap &avatar) {
    // 评论卡片容器
    QWidget *card = new QWidget();
    QHBoxLayout *cardLayout = new QHBoxLayout(card);

    // 用户头像
    QLabel *avatarLabel = new QLabel();
    avatarLabel->setPixmap(
        avatar.scaled(40, 40, Qt::KeepAspectRatio, Qt::SmoothTransformation)); // 缩放头像以适应容器

    // 评论文本
    QVBoxLayout *textLayout = new QVBoxLayout();
    QLabel *usernameLabel = new QLabel(username);
    QLabel *commentLabel = new QLabel(comment);
    usernameLabel->setStyleSheet("font-weight: bold;"); // 加粗用户名
    commentLabel->setWordWrap(true); // 支持换行

    textLayout->addWidget(usernameLabel);
    textLayout->addWidget(commentLabel);

    // 添加到布局
    cardLayout->addWidget(avatarLabel);
    cardLayout->addLayout(textLayout);

    // 设置卡片样式
    card->setStyleSheet("background-color: #f5f5f5; border: 1px solid #ccc; border-radius: 5px; padding: 10px;");
    card->setSizePolicy(QSizePolicy::Expanding, QSizePolicy::Fixed);

    commentsLayout->addWidget(card);
}
