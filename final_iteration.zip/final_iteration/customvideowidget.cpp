#include "customvideowidget.h"
#include <QDebug>

CustomVideoWidget::CustomVideoWidget(QWidget *parent)
    : QVideoWidget(parent) {
    // 初始化定时器
    hideTimer = new QTimer(this);
    hideTimer->setSingleShot(true); // 只触发一次
    connect(hideTimer, &QTimer::timeout, this, &CustomVideoWidget::hideProgressWidget);
}

void CustomVideoWidget::mouseDoubleClickEvent(QMouseEvent *event) {
    if (event->button() == Qt::LeftButton) {
        setFullScreen(!isFullScreen());
        event->accept();
    } else {
        QVideoWidget::mouseDoubleClickEvent(event);
    }
}

void CustomVideoWidget::enterEvent(QEvent *event) {
    if (!isMouseInside) {
        isMouseInside = true;
        emit showProgressWidget();    // 鼠标进入时显示进度条
        hideTimer->start(2000);       // 启动 3 秒延时定时器
    }
    QVideoWidget::enterEvent(event);  // 调用基类的enterEvent
}

void CustomVideoWidget::leaveEvent(QEvent *event) {
    if (isMouseInside) {
        isMouseInside = false;
        hideTimer->start(2000);       // 鼠标离开时，启动 3 秒延时定时器
    }
    QVideoWidget::leaveEvent(event);  // 调用基类的leaveEvent
}
