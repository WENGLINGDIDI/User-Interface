#ifndef CUSTOMVIDEOWIDGET_H
#define CUSTOMVIDEOWIDGET_H

#include <QVideoWidget>
#include <QMouseEvent>
#include <QTimer>


class CustomVideoWidget : public QVideoWidget {
    Q_OBJECT

public:
    explicit CustomVideoWidget(QWidget *parent = nullptr);

protected:
    void mouseDoubleClickEvent(QMouseEvent *event) override;

    // 重载鼠标进入和离开事件
    void enterEvent(QEvent *event) override;
    void leaveEvent(QEvent *event) override;
signals:
    void showProgressWidget();   // 显示进度条
    void hideProgressWidget();   // 隐藏进度条
private:
    QTimer *hideTimer;           // 定时器，用于隐藏进度条
    bool isMouseInside; // 标记鼠标是否在视频区域
};

#endif // CUSTOMVIDEOWIDGET_H
