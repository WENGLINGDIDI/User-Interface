#ifndef COMMENTWIDGET_H
#define COMMENTWIDGET_H

#include <QWidget>
#include <QVBoxLayout>
#include <QLabel>
#include <QPixmap>
#include <QScrollArea>

class CommentWidget : public QWidget {
    Q_OBJECT

public:
    explicit CommentWidget(QWidget *parent = nullptr);

    // 添加评论的方法
    void addComment(const QString &username, const QString &comment, const QPixmap &avatar);

private:
    QVBoxLayout *commentsLayout;
};

#endif // COMMENTWIDGET_H
