#ifndef LOGINWINDOW_H
#define LOGINWINDOW_H

#include <QWidget>
#include <QVBoxLayout>
#include <QPushButton>
#include <QLineEdit>
#include <QLabel>
#include <QMessageBox>
#include <QDialog>

class loginWindow : public QDialog {  // 继承 QDialog
    Q_OBJECT
public:
    loginWindow(QWidget *parent = nullptr) : QDialog(parent) {  // 使用 QDialog 构造函数
        setWindowTitle("Login");

        // 设置布局
        QVBoxLayout *layout = new QVBoxLayout(this);

        // 创建用户名和密码输入框
        QLabel *usernameLabel = new QLabel("Username:");
        QLineEdit *usernameEdit = new QLineEdit();
        QLabel *passwordLabel = new QLabel("Password:");
        QLineEdit *passwordEdit = new QLineEdit();

        passwordEdit->setEchoMode(QLineEdit::Password); // 设置密码框

        // 创建登录按钮
        QPushButton *loginButton = new QPushButton("Login");

        // 将控件添加到布局
        layout->addWidget(usernameLabel);
        layout->addWidget(usernameEdit);
        layout->addWidget(passwordLabel);
        layout->addWidget(passwordEdit);
        layout->addWidget(loginButton);

        // 连接登录按钮的点击信号到槽函数
        connect(loginButton, &QPushButton::clicked, this, [=]() {
            QString username = usernameEdit->text();
            QString password = passwordEdit->text();

            if (username == "admin" && password == "123") {
                // 登录成功，关闭登录窗口，进入主界面
                accept(); // 允许关闭窗口
            } else {
                // 登录失败，显示错误信息
                QMessageBox::warning(this, "Login Failed", "Incorrect username or password.");
            }
        });
    }
};
#endif // LOGINWINDOW_H
